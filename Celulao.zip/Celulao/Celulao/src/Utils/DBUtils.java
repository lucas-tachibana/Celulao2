/*
 *  Eduardo Braga da Silva RA: 20703156
 *  Lucas Akira Tachibana RA: 20763166
 *  Luciane Naomi Makiyama RA: 20869323 
 *  Ronilson Reis de Lima RA: 20704084
 */

package Utils;

/**
 *
 * @author Lucas
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class DBUtils {
    
    public static Connection getConnection() throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException{
		Class.forName("com.mysql.jdbc.Driver").newInstance();
		String strConn = "jdbc:mysql://127.0.0.1/Celulao?user=root&password=root";
		Connection conn = DriverManager.getConnection(strConn);
		return conn;
	}
	
	
	public static ResultSet getResultSet(Connection conn, String sql) throws SQLException{
		Statement st = conn.createStatement();
		return st.executeQuery(sql);
	}
	
	public static PreparedStatement getPreparedStatement(Connection conn, String sql) throws SQLException{
		return conn.prepareStatement(sql);
	}
}
