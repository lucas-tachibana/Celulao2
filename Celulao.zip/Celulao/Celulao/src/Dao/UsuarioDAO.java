/*
 *  Eduardo Braga da Silva RA: 20703156
 *  Lucas Akira Tachibana RA: 20763166
 *  Luciane Naomi Makiyama RA: 20869323 
 *  Ronilson Reis de Lima RA: 20704084
 */
package Dao;

import Utils.DBUtils;
import celulao.Entity.Usuario;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.List;

/**
 *
 * @author Lucas
 */
public class UsuarioDAO implements IAbstractDAO<Usuario>{

    @Override
    public List<Usuario> all() throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException {
        Connection conn = null;
        List<Usuario> todos = null;
        Usuario usuario = null;
        try {
            conn = DBUtils.getConnection();
            ResultSet rs = DBUtils.getResultSet(conn, "SELCT * FROM tb_usuario");
            
        } catch (Exception e) {
        }
        if (conn != null) {
            conn.close();
        }
        return todos;
    }

    @Override
    public Usuario findById(int id) throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void insert(Usuario entidade) throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException, ParseException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void update(Usuario entidade) throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void delete(Usuario entidade) throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
