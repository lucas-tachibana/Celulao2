/*
 *  Eduardo Braga da Silva RA: 20703156
 *  Lucas Akira Tachibana RA: 20763166
 *  Luciane Naomi Makiyama RA: 20869323 
 *  Ronilson Reis de Lima RA: 20704084
 */
package Dao;

import Utils.DBUtils;
import celulao.Entity.Cliente;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Lucas
 */
public class ClienteDAO implements IAbstractDAO<Cliente>{

    @Override
    public List<Cliente> all() throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException {
        Connection conn = null;
        Cliente cliente = null;
        List<Cliente> todos = null;
        try {
            conn = DBUtils.getConnection();
            ResultSet rs = DBUtils.getResultSet(conn, "SELECT * FROM tb_cliente");
            cliente = new Cliente();
            todos = new ArrayList<Cliente>();
            while (rs.next()) {
                cliente.setClienteID(rs.getInt("clienteID"));
                cliente.setNomeCliente(rs.getString("nomeCliente"));
                cliente.setEndereco(rs.getString("enderecoCliente"));
                cliente.setTelefone1(rs.getString("telefone1"));
                cliente.setTelefone1(rs.getString("telefone2"));
                cliente.setDataNascimento(rs.getDate("dtNascimento").toLocalDate());
                todos.add(cliente);
            }
        } catch (Exception e) {
        }
        if (conn != null) {
            conn.close();
        }
        return todos;
    }

    @Override
    public Cliente findById(int id) throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException {
        Connection conn = null;
        Cliente cliente = null;
        
        try {
            conn = DBUtils.getConnection();
            PreparedStatement ps = DBUtils.getPreparedStatement(conn, "SELECT * FROM tb_cliente WHERE clienteID = ?");
            ResultSet rs = ps.executeQuery();
            cliente = new Cliente();
            if (rs.next()) {
                cliente.setClienteID(rs.getInt("clienteID"));
                cliente.setNomeCliente(rs.getString("nomeCliente"));
                cliente.setEndereco(rs.getString("enderecoCliente"));
                cliente.setTelefone1(rs.getString("telefone1"));
                cliente.setTelefone1(rs.getString("telefone2"));
                cliente.setDataNascimento(rs.getDate("dtNascimento").toLocalDate());
            }
        } catch (Exception e) {
        }
        if (conn != null) {
            conn.close();
        }
        return cliente;
    }

    @Override
    public void insert(Cliente entidade) throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException, ParseException {
        Connection conn = null;
        try {
            conn = DBUtils.getConnection();
            PreparedStatement ps = DBUtils.getPreparedStatement(conn, "INSERT INTO tb_cliente "
                    + "(nomeCliente, enderecoCliente, telefone1, telefone2, dtNascimento) VALUES (?, ?, ?, ?, ?)");
            ps.setString(1, entidade.getNomeCliente());
            ps.setString(2, entidade.getEndereco());
            ps.setString(3, entidade.getTelefone1());
            ps.setString(4, entidade.getTelefone2());
            ps.setDate(5, Date.valueOf(entidade.getDataNascimento()));
            ps.execute();
        } catch (Exception e) {
        }
        if (conn != null) {
            conn.close();
        }
    }

    @Override
    public void update(Cliente entidade) throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException {
        Connection conn = null;
        try {
            conn = DBUtils.getConnection();
            PreparedStatement ps = DBUtils.getPreparedStatement(conn, "UPDATE tb_cliente "
                    + "SET nomeCliente = ?, enderecoCliente = ?, telefone1 = ?, telefone2 = ?, dtNascimento = ? WHERE clienteID = ?");
            ps.setString(1, entidade.getNomeCliente());
            ps.setString(2, entidade.getEndereco());
            ps.setString(3, entidade.getTelefone1());
            ps.setString(4, entidade.getTelefone2());
            ps.setDate(5, Date.valueOf(entidade.getDataNascimento()));
            ps.setInt(6, entidade.getClienteID());
            ps.execute();
        } catch (Exception e) {
        }
        if (conn != null) {
            conn.close();
        }
    }

    @Override
    public void delete(Cliente entidade) throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException {
        Connection conn = null;
        try {
            conn = DBUtils.getConnection();
            PreparedStatement ps = DBUtils.getPreparedStatement(conn, "DELETE FROM tb_cliente WHERE clienteID = ?");
            ps.setInt(1, entidade.getClienteID());
            ps.execute();
        } catch (Exception e) {
        }
        if (conn != null) {
            conn.close();
        }
    }
    
}
