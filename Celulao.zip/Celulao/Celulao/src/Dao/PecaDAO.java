/*
 *  Eduardo Braga da Silva RA: 20703156
 *  Lucas Akira Tachibana RA: 20763166
 *  Luciane Naomi Makiyama RA: 20869323 
 *  Ronilson Reis de Lima RA: 20704084
 */
package Dao;

import Utils.DBUtils;
import celulao.Entity.Peca;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Lucas
 */
public class PecaDAO implements IAbstractDAO<Peca>{

    @Override
    public List<Peca> all() throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException {
        Connection conn = null;
        List<Peca> todas = null;
        Peca peca = null;
        try {
            conn = DBUtils.getConnection();
            ResultSet rs = DBUtils.getResultSet(conn, "SELECT * FROM tb_peca");
            todas = new ArrayList<>();
            while (rs.next()) {
                peca = new Peca();
                peca.setPecaID(rs.getInt("pecaID"));
                peca.setDescricaoPeca(rs.getString("descricao"));
                peca.setCustoPeca(rs.getDouble("custoPeca"));
                todas.add(peca);
            }
        } catch (Exception e) {
        }
        if (conn != null) {
            conn.close();
        }
        return todas;
    }

    @Override
    public Peca findById(int id) throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException {
        Connection conn = null;
        Peca peca = null;
        try {
            conn = DBUtils.getConnection();
            PreparedStatement ps = DBUtils.getPreparedStatement(conn, "SELECT * FROM tb_peca WHERE pecaID = ?");
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                peca = new Peca();
                peca.setPecaID(rs.getInt("pecaID"));
                peca.setDescricaoPeca(rs.getString("descricao"));
                peca.setCustoPeca(rs.getDouble("custoPeca"));
            }
        } catch (Exception e) {
        }
        if (conn != null) {
            conn.close();
        }
        return peca;
    }

    @Override
    public void insert(Peca entidade) throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException, ParseException {
        Connection conn = null;
        try {
            conn = DBUtils.getConnection();
            PreparedStatement ps = DBUtils.getPreparedStatement(conn, "INSERT INTO tb_peca "
                    + "(descricao, custoPeca) VALUES (?, ?)");
            ps.setString(1, entidade.getDescricaoPeca());
            ps.setDouble(2, entidade.getCustoPeca());
            ps.execute();
        } catch (Exception e) {
        }
        if (conn != null) {
            conn.close();
        }
    }

    @Override
    public void update(Peca entidade) throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException {
        Connection conn = null;
        try {
            conn = DBUtils.getConnection();
            PreparedStatement ps = DBUtils.getPreparedStatement(conn, "UPDATE tb_peca "
                    + "SET descricao = ?, custoPeca = ? WHERE pecaID = ?");
            ps.setString(1, entidade.getDescricaoPeca());
            ps.setDouble(2, entidade.getCustoPeca());
            ps.setInt(3, entidade.getPecaID());
            ps.execute();
        } catch (Exception e) {
        }
        if (conn != null) {
            conn.close();
        }
    }

    @Override
    public void delete(Peca entidade) throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException {
        Connection conn = null;
        try {
            conn = DBUtils.getConnection();
            PreparedStatement ps = DBUtils.getPreparedStatement(conn, "DELETE FROM tb_peca WHERE pecaID = ?");
            ps.setInt(1, entidade.getPecaID());
            ps.execute();
        } catch (Exception e) {
        }
        if (conn != null) {
            conn.close();
        }
    }
    
}
