/*
 *  Eduardo Braga da Silva RA: 20703156
 *  Lucas Akira Tachibana RA: 20763166
 *  Luciane Naomi Makiyama RA: 20869323 
 *  Ronilson Reis de Lima RA: 20704084
 */
package Dao;

import Utils.DBUtils;
import celulao.Entity.OrdemServico;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Lucas
 */
public class OrdemServicoDAO implements IAbstractDAO<OrdemServico>{

    @Override
    public List<OrdemServico> all() throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException {
        Connection conn = null;
        List<OrdemServico> todos = null;
        OrdemServico ordem = null;
        try {
            conn = DBUtils.getConnection();
            ResultSet rs = DBUtils.getResultSet(conn, "SELECT * FROM tb_ordemServico");
            todos = new ArrayList<OrdemServico>();
            while (rs.next()) {
                ordem = new OrdemServico();
                ordem.setOsID(rs.getInt("ordemServicoID"));
                ordem.setDescricaoServico(rs.getString("descricaoServico"));
                ordem.setProblema1(rs.getString("problema1"));
                ordem.setProblema2(rs.getString("problema2"));
                ordem.setStatusOS(rs.getInt("statusOS"));
                ordem.setDataOS(rs.getDate("dataOS").toLocalDate());
                ordem.setCelularID(rs.getInt("aparelhoID"));
                ordem.setUserID(rs.getInt("usuarioID"));
                todos.add(ordem);
            }
        } catch (Exception e) {
        }
        if (conn != null) {
            conn.close();
        }
        return todos;
    }

    @Override
    public OrdemServico findById(int id) throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException {
        Connection conn = null;
        OrdemServico ordem = null;
        try {
            conn = DBUtils.getConnection();
            PreparedStatement ps = DBUtils.getPreparedStatement(conn, "SELECT * FROM tb_ordemServico WHERE ordemServicoID = ?");
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                ordem = new OrdemServico();
                ordem.setOsID(rs.getInt("ordemServicoID"));
                ordem.setDescricaoServico(rs.getString("descricaoServico"));
                ordem.setProblema1(rs.getString("problema1"));
                ordem.setProblema2(rs.getString("problema2"));
                ordem.setStatusOS(rs.getInt("statusOS"));
                ordem.setDataOS(rs.getDate("dataOS").toLocalDate());
                ordem.setCelularID(rs.getInt("aparelhoID"));
                ordem.setUserID(rs.getInt("usuarioID"));
            }
        } catch (Exception e) {
        }
        if (conn != null) {
            conn.close();
        }
        return ordem;
    }

    @Override
    public void insert(OrdemServico entidade) throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException, ParseException {
        Connection conn = null;
        try {
            conn = DBUtils.getConnection();
            PreparedStatement ps = DBUtils.getPreparedStatement(conn, "INSERT INTO tb_ordemServico "
                    + "(descricaoServico, problema1, problema2, statusOS, dataOS, aparelhoID, usuarioID) VALUES (?, ?, ?, ?, ?, ?, ?)");
            ps.setString(1, entidade.getDescricaoServico());
            ps.setString(2, entidade.getProblema1());
            ps.setString(3, entidade.getProblema2());
            ps.setInt(4, entidade.getStatusOS());
            ps.setDate(5, Date.valueOf(entidade.getDataOS()));
            ps.setInt(6, entidade.getCelularID());
            ps.setInt(7, entidade.getUserID());
            ps.execute();
        } catch (Exception e) {
        }
        if (conn != null) {
            conn.close();
        }
    }

    @Override
    public void update(OrdemServico entidade) throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException {
        Connection conn = null;
        try {
            conn = DBUtils.getConnection();
            PreparedStatement ps = DBUtils.getPreparedStatement(conn, "UPDATE tb_ordemServico "
                    + "SET descricaoServico = ?, problema1 = ?, problema2 = ?, statusOS = ?, dataOS = ?, aparelhoID = ?, usuarioID = ? "
                    + "WHERE ordemServicoID = ?");
            ps.setString(1, entidade.getDescricaoServico());
            ps.setString(2, entidade.getProblema1());
            ps.setString(3, entidade.getProblema2());
            ps.setInt(4, entidade.getStatusOS());
            ps.setDate(5, Date.valueOf(entidade.getDataOS()));
            ps.setInt(6, entidade.getCelularID());
            ps.setInt(7, entidade.getUserID());
            ps.setInt(8, entidade.getOsID());
            ps.execute();
        } catch (Exception e) {
        }
        if (conn != null) {
            conn.close();
        }
    }

    @Override
    public void delete(OrdemServico entidade) throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException {
        Connection conn = null;
        try {
            conn = DBUtils.getConnection();
            PreparedStatement ps = DBUtils.getPreparedStatement(conn, "DELETE FROM tb_ordemServico WHERE ordemServicoID = ?");
            ps.setInt(1, entidade.getOsID());
            ps.execute();
        } catch (Exception e) {
        }
        if (conn != null) {
            conn.close();
        }
    }
    
}
