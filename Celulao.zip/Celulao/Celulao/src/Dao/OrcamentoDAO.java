/*
 *  Eduardo Braga da Silva RA: 20703156
 *  Lucas Akira Tachibana RA: 20763166
 *  Luciane Naomi Makiyama RA: 20869323 
 *  Ronilson Reis de Lima RA: 20704084
 */
package Dao;

import Utils.DBUtils;
import celulao.Entity.Orcamento;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Lucas
 */
public class OrcamentoDAO implements IAbstractDAO<Orcamento>{

    @Override
    public List<Orcamento> all() throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException {
        Connection conn = null;
        Orcamento orcamento = null;
        List<Orcamento> todos = null;
        try {
            conn = DBUtils.getConnection();
            ResultSet rs = DBUtils.getResultSet(conn, "SELECT * FROM tb_orcamento");
            todos = new ArrayList<Orcamento>();
            while (rs.next()) {
                orcamento = new Orcamento();
                orcamento.setOrcamentoID(rs.getInt("ocamentoID"));
                orcamento.setDtOrc(rs.getDate("dtOrcamento").toLocalDate());
                orcamento.setValorServico(rs.getDouble("valorServico"));
                orcamento.setStatusOrc(rs.getInt("statusOrc"));
                orcamento.setDataAprov(rs.getDate("dataAprov").toLocalDate());
                orcamento.setValorPecas(rs.getDouble("valorPecas"));
                todos.add(orcamento);
            }
        } catch (Exception e) {
        }
        if (conn != null) {
            conn.close();
        }
        return todos;
    }

    @Override
    public Orcamento findById(int id) throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException {
        Connection conn = null;
        Orcamento orcamento = null;
        try {
            conn = DBUtils.getConnection();
            PreparedStatement ps = DBUtils.getPreparedStatement(conn, "SELECT * FROM tb_orcamento WHERE orcamentoID = ?");
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                orcamento = new Orcamento();
                orcamento.setOrcamentoID(rs.getInt("ocamentoID"));
                orcamento.setDtOrc(rs.getDate("dtOrcamento").toLocalDate());
                orcamento.setValorServico(rs.getDouble("valorServico"));
                orcamento.setStatusOrc(rs.getInt("statusOrc"));
                orcamento.setDataAprov(rs.getDate("dataAprov").toLocalDate());
                orcamento.setValorPecas(rs.getDouble("valorPecas"));
            }
        } catch (Exception e) {
        }
        if (conn != null) {
            conn.close();
        }
        return orcamento;
    }

    @Override
    public void insert(Orcamento entidade) throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException, ParseException {
        Connection conn = null;
        try {
            conn = DBUtils.getConnection();
            PreparedStatement ps = DBUtils.getPreparedStatement(conn, "INSERT INTO tb_orcamento "
                    + "(dtOrcamento, valorServico, statusOrc, dataAprov, valorPecas) VALUES (?, ?, ?, ?, ?)");
            ps.setDate(1, Date.valueOf(entidade.getDtOrc()));
            ps.setDouble(2, entidade.getValorServico());
            ps.setInt(3, entidade.getStatusOrc());
            ps.setDate(4, Date.valueOf(entidade.getDataAprov()));
            ps.setDouble(5, entidade.getValorPecas());
            ps.execute();
        } catch (Exception e) {
        }
        if (conn != null) {
            conn.close();
        }
    }

    @Override
    public void update(Orcamento entidade) throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException {
        Connection conn = null;
        try {
            conn = DBUtils.getConnection();
            PreparedStatement ps = DBUtils.getPreparedStatement(conn, "UPDATE tb_orcamento "
                    + "SET dtOrcamento = ?, valorServico = ?, statusOrc = ?, dataAprov = ?, valorPecas = ? WHERE orcamentoID = ?");
            ps.setDate(1, Date.valueOf(entidade.getDtOrc()));
            ps.setDouble(2, entidade.getValorServico());
            ps.setInt(3, entidade.getStatusOrc());
            ps.setDate(4, Date.valueOf(entidade.getDataAprov()));
            ps.setDouble(5, entidade.getValorPecas());
            ps.setInt(6, entidade.getOrcamentoID());
            ps.execute();
        } catch (Exception e) {
        }
        if (conn != null) {
            conn.close();
        }
    }

    @Override
    public void delete(Orcamento entidade) throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException {
        Connection conn = null;
        try {
            conn = DBUtils.getConnection();
            PreparedStatement ps = DBUtils.getPreparedStatement(conn, "DELETE FROM tb_orcamento WHERE orcamentoID = ?");
            ps.setInt(1, entidade.getOrcamentoID());
            ps.execute();
        } catch (Exception e) {
        }
        if (conn != null) {
            conn.close();
        }
    }
    
}
