/*
 *  Eduardo Braga da Silva RA: 20703156
 *  Lucas Akira Tachibana RA: 20763166
 *  Luciane Naomi Makiyama RA: 20869323 
 *  Ronilson Reis de Lima RA: 20704084
 */

package Dao;

/**
 *
 * @author Lucas
 */
import java.sql.SQLException;
import java.text.ParseException;
import java.util.List;

public interface IAbstractDAO<T> {
	
	List<T> all() throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException;
	T findById(int id) throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException;
	void insert(T entidade) throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException, ParseException;
	void update(T entidade) throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException;
	void delete(T entidade) throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException;
}
