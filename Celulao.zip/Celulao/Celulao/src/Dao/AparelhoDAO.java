/*
 *  Eduardo Braga da Silva RA: 20703156
 *  Lucas Akira Tachibana RA: 20763166
 *  Luciane Naomi Makiyama RA: 20869323 
 *  Ronilson Reis de Lima RA: 20704084
 */

package Dao;

/**
 *
 * @author Lucas
 */
import Utils.DBUtils;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import celulao.Entity.*;
import java.sql.PreparedStatement;


public class AparelhoDAO implements IAbstractDAO<Aparelho> {

    @Override
    public List all() throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException {
        Connection conn = null;
        Aparelho aparelho = null;
        List<Aparelho> todos = null;
        try {
            conn = DBUtils.getConnection();
            ResultSet rs = DBUtils.getResultSet(conn, "SELECT * FROM tb_aparelho");
            todos = new ArrayList<Aparelho>();
            while (rs.next()) {
                aparelho = new Aparelho();
                aparelho.setCelularID(rs.getInt("aparelhoID"));
                aparelho.setCelularModelo(rs.getString("modelo"));
                todos.add(aparelho);
            }
        } catch (Exception e) {
        }
        if (conn != null) {
            conn.close();
        }
        return todos;
    }

    @Override
    public Aparelho findById(int id) throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException {
        Connection conn = null;
        Aparelho aparelho = null;
        try {
            conn = DBUtils.getConnection();
            PreparedStatement ps = DBUtils.getPreparedStatement(conn, "SELECT * FROM tb_aparelho WHERE aparelhoID = ?");
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            aparelho = new Aparelho();
            if (rs.next()) {
                aparelho.setCelularID(rs.getInt("aparelhoID"));
                aparelho.setCelularModelo(rs.getString("modelo"));
            }
        } catch (Exception e) {
        }
        if (conn != null) {
            conn.close();
        }
        return aparelho;
    }

    @Override
    public void insert(Aparelho entidade) throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException, ParseException {
        Connection conn = null;
        try {
            conn = DBUtils.getConnection();
            PreparedStatement ps = DBUtils.getPreparedStatement(conn, "INSERT INTO tb_aparelho (modelo) VALUES (?)");
            ps.setString(1, entidade.getCelularModelo());
            ps.execute();
            
        } catch (Exception e) {
        }
        if (conn != null) {
            conn.close();
        }
    }

    @Override
    public void update(Aparelho entidade) throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException {
        Connection conn = null;
        try {
            conn = DBUtils.getConnection();
            PreparedStatement ps = DBUtils.getPreparedStatement(conn, "UPDATE tb_aparelho SET modelo = ? WHERE aparelhoID = ?");
            ps.setString(1, entidade.getCelularModelo());
            ps.setInt(2, entidade.getCelularID());
            ps.execute();
            
        } catch (Exception e) {
        }
        if (conn != null) {
            conn.close();
        }
    }

    @Override
    public void delete(Aparelho entidade) throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException {
        Connection conn = null;
        try {
            conn = DBUtils.getConnection();
            PreparedStatement ps = DBUtils.getPreparedStatement(conn, "DELETE FROM tb_aparelho WHERE aparelhoID = ?");
            ps.setInt(1, entidade.getCelularID());
            ps.execute();
            
        } catch (Exception e) {
        }
        if (conn != null) {
            conn.close();
        }
    }

    
}
