/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package celulao.Entity;

import java.util.Date;

/**
 *
 * @author Naomi
 */
public class Usuario {
    private int userID;
    private String nomeUser;
    private int nivelUser;
    private Date dataCadastro;
    
    //Construtor
    public Usuario(){
    }
    
    //métodos de acesso

    public int getUserID() {
        return userID;
    }
    //o SGBD se encarregará de auto incrementar o pecaID
    public void setUserID(int userID) {
        this.userID = userID;
    }

    public String getNomeUser() {
        return nomeUser;
    }

    public void setNomeUser(String nomeUser) {
        this.nomeUser = nomeUser;
    }

    public int getNivelUser() {
        return nivelUser;
    }

    public void setNivelUser(int nivelUser) {
        this.nivelUser = nivelUser;
    }

    public Date getDataCadastro() {
        return dataCadastro;
    }

    public void setDataCadastro(Date dataCadastro) {
        this.dataCadastro = dataCadastro;
    }

    
}
