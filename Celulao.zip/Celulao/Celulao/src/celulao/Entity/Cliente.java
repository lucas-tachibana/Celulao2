/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package celulao.Entity;

import java.time.LocalDate;

/**
 *
 * @author Naomi
 */
public class Cliente {
    private int clienteID;
    private String nomeCliente;
    private String endereco;
    private String telefone1;
    private String telefone2;
    private LocalDate dataNascimento;

    //Construtor
    public Cliente() {
    }

    //métodos de acesso

    public int getClienteID() {
        return clienteID;
    }
    //o SGBD se encarregará de auto incrementar o clienteID
    public void setClienteID(int clienteID) {
        this.clienteID = clienteID;
    }

    public String getNomeCliente() {
        return nomeCliente;
    }

    public void setNomeCliente(String nomeCliente) {
        this.nomeCliente = nomeCliente;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getTelefone1() {
        return telefone1;
    }

    public void setTelefone1(String telefone1) {
        this.telefone1 = telefone1;
    }

    public String getTelefone2() {
        return telefone2;
    }

    public void setTelefone2(String telefone2) {
        this.telefone2 = telefone2;
    }

    public LocalDate getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(LocalDate dataNascimento) {
        this.dataNascimento = dataNascimento;
    }
    
    
}
