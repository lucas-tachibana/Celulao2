/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package celulao.Entity;

import java.time.LocalDate;

/**
 *
 * @author Naomi
 */
public class OrdemServico {
    private int osID;
    private String descricaoServico;
    private int clienteID;
    private int celularID;
    private String problema1;
    private String problema2;
    private int statusOS;
    private LocalDate dataOS;
    private int userID;

    //Construtor
    public OrdemServico() {
    }

    //métodos de acesso

    public int getOsID() {
        return osID;
    }

    //o SGBD se encarregará de auto incrementar o OsID
    public void setOsID(int osID) {
        this.osID = osID;
    }

    public String getDescricaoServico() {
        return descricaoServico;
    }

    public void setDescricaoServico(String descricaoServico) {
        this.descricaoServico = descricaoServico;
    }

    public int getClienteID() {
        return clienteID;
    }

    public void setClienteID(int clienteID) {
        this.clienteID = clienteID;
    }

    public int getCelularID() {
        return celularID;
    }

    public void setCelularID(int celularID) {
        this.celularID = celularID;
    }

    public String getProblema1() {
        return problema1;
    }

    public void setProblema1(String problema1) {
        this.problema1 = problema1;
    }

    public String getProblema2() {
        return problema2;
    }

    public void setProblema2(String problema2) {
        this.problema2 = problema2;
    }

    public int getStatusOS() {
        return statusOS;
    }

    public void setStatusOS(int statusOS) {
        this.statusOS = statusOS;
    }

    public LocalDate getDataOS() {
        return dataOS;
    }

    public void setDataOS(LocalDate dataOS) {
        this.dataOS = dataOS;
    }

    public int getUserID() {
        return userID;
    }

    public void setUserID(int userID) {
        this.userID = userID;
    }
    
}
