/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package celulao.Entity;

import java.time.LocalDate;
import java.util.Date;

/**
 *
 * @author Naomi
 */
public class Orcamento {
    private int orcamentoID;
    private Double valorServico;
    private LocalDate dtOrc;
    private int statusOrc;
    private LocalDate dataAprov;
    private Double valorPecas;
    
    //Construtor
    public Orcamento(){}
    
    //métodos de acesso

    public int getOrcamentoID() {
        return orcamentoID;
    }

    public Double getValorServico() {
        return valorServico;
    }

    public LocalDate getDtOrc() {
        return dtOrc;
    }

    public int getStatusOrc() {
        return statusOrc;
    }

    public LocalDate getDataAprov() {
        return dataAprov;
    }

    public Double getValorPecas() {
        return valorPecas;
    }

    //o SGBD se encarregará de auto incrementar o orcamentoID
    public void setOrcamentoID(int orcamentoID) {
        this.orcamentoID = orcamentoID;
    }

    public void setValorServico(Double valorServico) {
        this.valorServico = valorServico;
    }

    public void setDtOrc(LocalDate dtOrc) {
        this.dtOrc = dtOrc;
    }

    public void setStatusOrc(int statusOrc) {
        this.statusOrc = statusOrc;
    }

    public void setDataAprov(LocalDate dataAprov) {
        this.dataAprov = dataAprov;
    }

    public void setValorPecas(Double valorPecas) {
        this.valorPecas = valorPecas;
    }
    
}
