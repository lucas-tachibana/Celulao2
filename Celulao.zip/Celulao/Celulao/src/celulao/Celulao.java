/*
 *  Eduardo Braga da Silva RA: 20703156
 *  Lucas Akira Tachibana RA: 20763166
 *  Luciane Naomi Makiyama RA: 20869323 
 *  Ronilson Reis de Lima RA: 20704084
 */

package celulao;

import Telas.*;
/**
 *
 * @author Naomi
 */
public class Celulao {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        new frmLogin().setVisible(true);
    }
    
}
